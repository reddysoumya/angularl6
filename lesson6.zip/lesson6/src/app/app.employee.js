"use strict";
var Employee = (function () {
    function Employee() {
    }
    return Employee;
}());
exports.Employee = Employee;
